<?php $max_story_num = $this->db->get_where('frontend_settings', array('type' => 'max_story_num'))->row()->value; ?>
<form class="form-horizontal" id="happy_stories_form" method="POST" action="<?=base_url()?>admin/save_frontend_settings/home_happy_stories">
	<div class="form-group">
		<label class="col-sm-2 control-label" for="max_story_num"><b><?php echo translate('max_happy_stories_number')?></b></label>
        <div class="col-sm-9">
        	<input type="number" class="form-control" id="max_story_num" name="max_story_num" value="<?=$max_story_num?>" min="5" max="40" required="">
        </div>
	</div>
	<div class="form-group">
		<div class="col-sm-offset-2 col-sm-9">
        	<button type="submit" class="btn btn-primary btn-sm btn-labeled fa fa-save"><?php echo translate('submit')?></button>
		</div>
	</div>
</form>