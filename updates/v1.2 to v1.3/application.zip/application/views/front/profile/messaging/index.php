<div class="card-title">
    <h3 class="heading heading-6 strong-500">
        <b><?php echo translate('messaging')?></b>
    </h3>
</div>
<div class="card-body">
    <div class="row">
        <div class="col-md-8 mb-2">
            <!-- DIRECT CHAT -->
            <div id="profile_message_box">
                <?php include 'message_box.php'; ?>
            </div>
            
            <!--/.direct-chat -->
        </div>
        <!-- /.col -->
        <div class="col-md-4">
            <div id="messaging_member_list">
                <?php include 'member_list.php'; ?>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){
        window.addEventListener("keydown", checkKeyPressed, false);
        function checkKeyPressed(e) {
            if (e.keyCode == "13") {
                $(":focus").each(function() {
                    event.preventDefault();
                    $(this).closest('form').find('.enterer').click();
                });
            }
        }

        $("#message_text").keyup(function(){
            if ($("#message_text").val().length != 0) {
                $("#msg_send_btn").removeAttr('disabled');
            }
            else {
                $("#msg_send_btn").attr('disabled', 'disabled');   
            }
        });
    });
</script>